import React from "react";
import {
  Grid,
  Flame,
  Swords,
  Castle,
  Ghost,
  Building2,
  Footprints,
  Crosshair,
  Car,
  MousePointerClick,
  ArrowUpDown
} from "lucide-react";

interface CategoryTabsProps {
  selectedCategory: string;
  onSelectCategory: (cat: string) => void;
  sortBy: string;
  onSortChange: (sort: string) => void;
  gameCount: number;
}

const CATEGORIES = [
  { id: "All", name: "All", icon: Grid },
  { id: "Trending", name: "🔥 Trending", icon: Flame },
  { id: "Incremental & Idle", name: "⚡ Incremental & Idle", icon: MousePointerClick },
  { id: "Anime & Action", name: "⚔️ Anime & Action", icon: Swords },
  { id: "RPG & Adventure", name: "🏰 RPG", icon: Castle },
  { id: "Horror & Thriller", name: "👻 Horror", icon: Ghost },
  { id: "Tycoons & Simulators", name: "🏢 Simulators", icon: Building2 },
  { id: "Obby & Casual", name: "🏃 Obby & Casual", icon: Footprints },
  { id: "PVP & Shooter", name: "🎯 PVP", icon: Crosshair },
  { id: "Driving & Sports", name: "🏎️ Driving", icon: Car },
];

export const CategoryTabs: React.FC<CategoryTabsProps> = ({
  selectedCategory,
  onSelectCategory,
  sortBy,
  onSortChange,
  gameCount,
}) => {
  return (
    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6 bg-slate-900/60 p-2.5 rounded-2xl border border-slate-800">
      {/* Scrollable Horizontal Pill Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 custom-scrollbar">
        {CATEGORIES.map((cat) => {
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => onSelectCategory(cat.id)}
              className={`px-3 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all flex items-center gap-1.5 cursor-pointer shrink-0 ${
                isSelected
                  ? "bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 shadow-md shadow-cyan-500/20 scale-[1.02]"
                  : "bg-slate-900 text-slate-400 hover:text-white hover:bg-slate-800 border border-slate-800"
              }`}
            >
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Sort Dropdown and Results Counter */}
      <div className="flex items-center justify-between sm:justify-end gap-3 w-full sm:w-auto shrink-0 pt-2 sm:pt-0 border-t sm:border-t-0 border-slate-800">
        <span className="text-xs text-slate-400 font-medium">
          Showing <strong className="text-white font-mono">{gameCount}</strong> maps
        </span>

        <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 rounded-xl px-2.5 py-1.5">
          <ArrowUpDown className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-[11px] text-slate-400 font-semibold hidden md:inline">Sort:</span>
          <select
            value={sortBy}
            onChange={(e) => onSortChange(e.target.value)}
            className="bg-transparent text-xs text-slate-200 font-semibold focus:outline-none cursor-pointer"
          >
            <option value="playing" className="bg-slate-900 text-white">Most Players Now</option>
            <option value="rating" className="bg-slate-900 text-white">Highest Upvote %</option>
            <option value="growth" className="bg-slate-900 text-white">Fastest 24h Growth</option>
            <option value="peak" className="bg-slate-900 text-white">24h Peak Players</option>
            <option value="name" className="bg-slate-900 text-white">Alphabetical (A-Z)</option>
          </select>
        </div>
      </div>
    </div>
  );
};
