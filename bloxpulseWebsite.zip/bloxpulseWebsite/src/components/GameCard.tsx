import React from "react";
import { Users, ThumbsUp, Bookmark, Play, Sparkles, ExternalLink, Flame, TrendingUp } from "lucide-react";
import { RobloxGame } from "../types";

interface GameCardProps {
  game: RobloxGame;
  onSelectGame: (game: RobloxGame) => void;
  isWatchlisted: boolean;
  onToggleWatchlist: (game: RobloxGame) => void;
}

export const GameCard: React.FC<GameCardProps> = React.memo(({
  game,
  onSelectGame,
  isWatchlisted,
  onToggleWatchlist,
}) => {
  // Simple mini SVG Sparkline generator from array
  const renderMiniSparkline = (data: number[]) => {
    if (!data || data.length < 2) return null;
    const min = Math.min(...data);
    const max = Math.max(...data);
    const range = max - min || 1;
    const width = 100;
    const height = 28;

    const points = data
      .map((val, idx) => {
        const x = (idx / (data.length - 1)) * width;
        const y = height - ((val - min) / range) * (height - 4) - 2;
        return `${x.toFixed(1)},${y.toFixed(1)}`;
      })
      .join(" ");

    return (
      <div className="flex items-center gap-2 mt-2 pt-2 border-t border-slate-800/80">
        <span className="text-[10px] text-slate-500 font-medium">24h Pulse</span>
        <svg className="w-full h-7 overflow-visible" viewBox={`0 0 ${width} ${height}`}>
          <defs>
            <linearGradient id={`sparkGrad-${game.id}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
            </linearGradient>
          </defs>
          <path
            d={`M 0,${height} L ${points} L ${width},${height} Z`}
            fill={`url(#sparkGrad-${game.id})`}
          />
          <polyline
            fill="none"
            stroke="#06b6d4"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            points={points}
          />
        </svg>
      </div>
    );
  };

  const displayImage = (game.iconUrl || game.bannerUrl || "").replace(/\/150\/150\//g, "/512/512/");

  return (
    <div className="group relative bg-slate-900/90 border border-slate-800/90 hover:border-cyan-500/50 rounded-2xl overflow-hidden shadow-xl hover:shadow-cyan-500/10 transition-all duration-300 flex flex-col justify-between">
      
      {/* Top Banner & Thumbnail Image */}
      <div className="relative h-44 overflow-hidden bg-slate-950">
        <img
          src={displayImage}
          alt={game.name}
          referrerPolicy="no-referrer"
          onError={(e) => {
            // Fallback if image load fails
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=500&auto=format&fit=crop&q=80";
          }}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 opacity-90 group-hover:opacity-100"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/30 to-transparent" />

        {/* Live Active Player Badge (Top Left) */}
        <div className="absolute top-3 left-3 bg-slate-950/90 backdrop-blur-md border border-slate-800/90 px-2.5 py-1 rounded-xl flex items-center gap-1.5 shadow-md">
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
          </span>
          <Users className="w-3.5 h-3.5 text-cyan-400" />
          <span className="text-xs font-black text-white font-mono">{game.activePlayers.toLocaleString()}</span>
        </div>

        {/* Watchlist Star Toggle (Top Right) */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWatchlist(game);
          }}
          className={`absolute top-3 right-3 p-2 rounded-xl backdrop-blur-md border transition-all cursor-pointer ${
            isWatchlisted
              ? "bg-amber-500 text-slate-950 border-amber-400 shadow-lg shadow-amber-500/30"
              : "bg-slate-950/80 text-slate-300 hover:text-amber-400 border-slate-800 hover:border-amber-400/50"
          }`}
          title={isWatchlisted ? "Remove from Watchlist" : "Add to Watchlist"}
        >
          <Bookmark className="w-4 h-4 fill-current" />
        </button>

        {/* Category Pill Tag */}
        <div className="absolute bottom-3 left-3 flex items-center gap-2">
          <span className="px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider bg-slate-950/90 text-cyan-300 border border-cyan-500/30 rounded-lg">
            {game.category}
          </span>
          {game.isTrending && (
            <span className="px-2 py-0.5 text-[10px] font-black uppercase tracking-wider bg-gradient-to-r from-amber-500 to-red-500 text-slate-950 rounded-lg flex items-center gap-0.5 shadow-md">
              <Flame className="w-3 h-3" /> Trending
            </span>
          )}
        </div>
      </div>

      {/* Main Details Body */}
      <div className="p-4 flex-1 flex flex-col justify-between">
        <div>
          <div className="flex items-start justify-between gap-2 mb-1">
            <h3
              onClick={() => onSelectGame(game)}
              className="text-base font-extrabold text-white group-hover:text-cyan-400 transition-colors cursor-pointer line-clamp-1"
            >
              {game.name}
            </h3>
          </div>

          <p className="text-xs text-slate-400 mb-2 flex items-center justify-between">
            <span>by <span className="text-slate-300 font-semibold">{game.creator}</span></span>
            <a
              href={`https://www.rolimons.com/game/${game.placeId}`}
              target="_blank"
              rel="noopener noreferrer"
              className="text-[10px] font-mono text-indigo-400 hover:text-indigo-300 hover:underline flex items-center gap-0.5"
              title="View place on Rolimons Database"
            >
              Rolimons #{game.placeId} <ExternalLink className="w-2.5 h-2.5" />
            </a>
          </p>

          <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-3">
            {game.description}
          </p>

          {/* Stats Bar (Upvote %, 24h Peak, Growth) */}
          <div className="grid grid-cols-3 gap-2 bg-slate-950/60 p-2 rounded-xl border border-slate-800 text-center">
            <div>
              <span className="text-[10px] text-slate-500 block">Rating</span>
              <span className="text-xs font-bold text-emerald-400 flex items-center justify-center gap-1">
                <ThumbsUp className="w-3 h-3" /> {game.upvotePercentage}%
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">24h Peak</span>
              <span className="text-xs font-bold text-slate-200 font-mono">
                {game.peak24h > 1000 ? `${(game.peak24h / 1000).toFixed(1)}k` : game.peak24h}
              </span>
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block">24h Growth</span>
              <span className="text-xs font-bold text-cyan-400 flex items-center justify-center gap-0.5 font-mono">
                <TrendingUp className="w-3 h-3" /> +{game.growth24h}%
              </span>
            </div>
          </div>

          {/* Mini Sparkline Chart */}
          {renderMiniSparkline(game.sparkline)}
        </div>

        {/* Action Buttons Footers */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-2">
          <button
            onClick={() => onSelectGame(game)}
            className="flex-1 py-2 px-3 bg-slate-800 hover:bg-slate-700 text-slate-100 font-bold text-xs rounded-xl border border-slate-700 hover:border-cyan-500/50 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <span>Pulse Stats</span>
          </button>

          <a
            href={`https://www.roblox.com/games/${game.placeId}`}
            target="_blank"
            rel="noopener noreferrer"
            className="p-2 bg-emerald-500/20 hover:bg-emerald-500 text-emerald-400 hover:text-slate-950 border border-emerald-500/30 rounded-xl transition-all cursor-pointer flex items-center justify-center"
            title="Launch Roblox Experience"
          >
            <Play className="w-4 h-4 fill-current" />
          </a>
        </div>

      </div>
    </div>
  );
});

