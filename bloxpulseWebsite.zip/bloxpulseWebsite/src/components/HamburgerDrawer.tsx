import React from "react";
import {
  X,
  Flame,
  Swords,
  Castle,
  Ghost,
  Building2,
  Footprints,
  Crosshair,
  Car,
  Grid,
  Bookmark,
  Activity,
  PlusCircle,
  ExternalLink,
  ShieldCheck,
  Radio,
  MousePointerClick
} from "lucide-react";

interface HamburgerDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  activeCategory: string;
  onSelectCategory: (cat: string) => void;
  activeView: "all" | "watchlist" | "analytics";
  onChangeView: (view: "all" | "watchlist" | "analytics") => void;
  onOpenAddGame: () => void;
  watchlistCount: number;
  totalTrackedGames: number;
}

const CATEGORIES = [
  { name: "All", label: "All Experiences", icon: Grid, count: null },
  { name: "Trending", label: "🔥 Top Trending & Viral", icon: Flame, count: "Hot" },
  { name: "Incremental & Idle", label: "⚡ Incremental & Idle", icon: MousePointerClick, count: "New" },
  { name: "Anime & Action", label: "⚔️ Anime & Action", icon: Swords, count: "Popular" },
  { name: "RPG & Adventure", label: "🏰 RPG & Adventure", icon: Castle, count: "Top" },
  { name: "Horror & Thriller", label: "👻 Horror & Thriller", icon: Ghost, count: "Spooky" },
  { name: "Tycoons & Simulators", label: "🏢 Tycoons & Simulators", icon: Building2, count: "Popular" },
  { name: "Obby & Casual", label: "🏃 Obby & Casual", icon: Footprints, count: "Top" },
  { name: "PVP & Shooter", label: "🎯 PVP & Shooter", icon: Crosshair, count: "Action" },
  { name: "Driving & Sports", label: "🏎️ Driving & Sports", icon: Car, count: "Fast" },
];

export const HamburgerDrawer: React.FC<HamburgerDrawerProps> = ({
  isOpen,
  onClose,
  activeCategory,
  onSelectCategory,
  activeView,
  onChangeView,
  onOpenAddGame,
  watchlistCount,
  totalTrackedGames,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden font-sans">
      {/* Backdrop overlay */}
      <div
        className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm transition-opacity animate-in fade-in duration-200"
        onClick={onClose}
      />

      {/* Drawer Container */}
      <div className="fixed inset-y-0 left-0 max-w-full flex">
        <div className="w-screen max-w-sm bg-slate-950 border-r border-slate-800/90 text-slate-100 p-6 flex flex-col justify-between shadow-2xl z-10 transform transition-all duration-300 animate-in slide-in-from-left">
          
          {/* Header */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-800">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-gradient-to-br from-cyan-500 to-emerald-500 rounded-xl text-slate-950 font-bold shadow-md shadow-cyan-500/20">
                <Activity className="w-5 h-5" />
              </div>
              <div>
                <h2 className="text-lg font-black text-white tracking-tight">
                  BLOX<span className="text-cyan-400">PULSE</span> NAV
                </h2>
                <p className="text-[11px] text-slate-400">Roblox Real-Time Directory</p>
              </div>
            </div>

            <button
              id="close-hamburger-drawer-btn"
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-900 hover:bg-slate-800 border border-slate-800 rounded-xl transition-all cursor-pointer"
              aria-label="Close Navigation Menu"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Navigation Sections */}
          <div className="flex-1 overflow-y-auto my-4 pr-1 space-y-6 custom-scrollbar">
            
            {/* Quick Views */}
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">
                Main Views
              </p>
              <div className="space-y-1">
                <button
                  onClick={() => {
                    onChangeView("all");
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeView === "all"
                      ? "bg-gradient-to-r from-cyan-500/20 to-emerald-500/20 text-cyan-300 border border-cyan-500/30"
                      : "text-slate-300 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Grid className="w-4 h-4 text-cyan-400" />
                    <span>All Maps Directory</span>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] bg-slate-900 text-slate-400 rounded-full border border-slate-800">
                    {totalTrackedGames}
                  </span>
                </button>

                <button
                  onClick={() => {
                    onChangeView("watchlist");
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeView === "watchlist"
                      ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                      : "text-slate-300 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Bookmark className="w-4 h-4 text-amber-400" />
                    <span>Watchlist & Alerts</span>
                  </div>
                  <span className="px-2 py-0.5 text-[10px] bg-amber-500/20 text-amber-300 font-bold rounded-full border border-amber-500/30">
                    {watchlistCount}
                  </span>
                </button>

                <button
                  onClick={() => {
                    onChangeView("analytics");
                    onClose();
                  }}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all cursor-pointer ${
                    activeView === "analytics"
                      ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                      : "text-slate-300 hover:bg-slate-900 hover:text-white"
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Activity className="w-4 h-4 text-indigo-400" />
                    <span>Network Health & Analytics</span>
                  </div>
                  <span className="px-1.5 py-0.5 text-[10px] bg-indigo-500/20 text-indigo-300 rounded-full">
                    Live
                  </span>
                </button>
              </div>
            </div>

            {/* Categorized Game Sections */}
            <div>
              <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-2">
                Categories
              </p>
              <div className="space-y-1">
                {CATEGORIES.map((cat) => {
                  const Icon = cat.icon;
                  const isSelected = activeCategory === cat.name && activeView === "all";
                  return (
                    <button
                      key={cat.name}
                      onClick={() => {
                        onSelectCategory(cat.name);
                        onChangeView("all");
                        onClose();
                      }}
                      className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer ${
                        isSelected
                          ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 font-semibold"
                          : "text-slate-300 hover:bg-slate-900 hover:text-white"
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <Icon className={`w-4 h-4 ${isSelected ? "text-cyan-400" : "text-slate-400"}`} />
                        <span>{cat.label}</span>
                      </div>
                      {cat.count && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-slate-900 text-slate-400 border border-slate-800">
                          {cat.count}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Track Custom Place ID Action */}
            <div className="p-3 bg-gradient-to-b from-slate-900 to-slate-900/60 rounded-2xl border border-slate-800">
              <div className="flex items-center gap-2 text-cyan-400 font-bold text-xs mb-1">
                <PlusCircle className="w-4 h-4" />
                <span>Track Any Roblox Map</span>
              </div>
              <p className="text-[11px] text-slate-400 mb-3 leading-relaxed">
                Add a Roblox Place ID to track live player counts, peak trends, and server region latencies in real-time.
              </p>
              <button
                onClick={() => {
                  onOpenAddGame();
                  onClose();
                }}
                className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Add Place ID</span>
              </button>
            </div>
          </div>

          {/* Footer Info */}
          <div className="pt-4 border-t border-slate-800 text-xs text-slate-500 space-y-2">
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1.5 text-slate-400">
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Roblox API Status</span>
              </span>
              <span className="text-emerald-400 font-mono font-bold text-[11px]">99.9% Online</span>
            </div>
            <a
              href="https://www.roblox.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-between text-slate-400 hover:text-cyan-400 transition-colors pt-1"
            >
              <span>Official Roblox Web</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>

        </div>
      </div>
    </div>
  );
};
