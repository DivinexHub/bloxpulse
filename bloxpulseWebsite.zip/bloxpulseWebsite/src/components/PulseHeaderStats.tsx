import React from "react";
import { Users, TrendingUp, RefreshCw, Clock, Activity, Zap } from "lucide-react";
import { PulseStats } from "../types";

interface PulseHeaderStatsProps {
  stats: PulseStats | null;
  trendingCount: number;
  isRefreshing?: boolean;
  onManualRefresh?: () => void;
  manualRefreshCount?: number;
  lastUpdatedTime?: string | null;
}

export const PulseHeaderStats: React.FC<PulseHeaderStatsProps> = ({
  stats,
  trendingCount,
  isRefreshing = false,
  onManualRefresh,
  manualRefreshCount = 0,
  lastUpdatedTime,
}) => {
  const totalActive = stats?.totalActivePlayers || 0;
  const totalPeak = stats?.totalPeak24h || 0;
  const tracked = stats?.trackedGames || 0;

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5 mb-6">
      {/* Total Active Players */}
      <div className="relative overflow-hidden bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg hover:border-cyan-500/40 transition-all group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-cyan-500/10 rounded-full blur-2xl group-hover:bg-cyan-500/20 transition-all pointer-events-none" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-400">Total Active Players</span>
          <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <Users className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl lg:text-3xl font-black text-white font-mono tracking-tight">
            {totalActive.toLocaleString()}
          </span>
          <span className="text-xs font-bold text-emerald-400 flex items-center gap-0.5">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping inline-block" />
            Live
          </span>
        </div>
        <div className="flex items-center justify-between mt-1 text-[11px] text-slate-500">
          <span>Concurrent Roblox map players</span>
          {lastUpdatedTime && (
            <span className="text-slate-400 font-mono text-[10px] flex items-center gap-1">
              <Clock className="w-3 h-3 text-cyan-400" />
              {lastUpdatedTime}
            </span>
          )}
        </div>
      </div>

      {/* 24h Peak Players */}
      <div className="relative overflow-hidden bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg hover:border-emerald-500/40 transition-all group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all pointer-events-none" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-400">24h Network Peak</span>
          <div className="p-2 rounded-xl bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <TrendingUp className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl lg:text-3xl font-black text-white font-mono tracking-tight">
            {totalPeak.toLocaleString()}
          </span>
          <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-1.5 py-0.5 rounded border border-emerald-500/20">
            High Surge
          </span>
        </div>
        <p className="text-[11px] text-slate-500 mt-1">Highest 24-hour player spike</p>
      </div>

      {/* Tracked experiences & Manual Refresh Count */}
      <div className="relative overflow-hidden bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg hover:border-amber-500/40 transition-all group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition-all pointer-events-none" />
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-semibold text-slate-400">Tracked Experiences</span>
          {onManualRefresh && (
            <button
              onClick={onManualRefresh}
              disabled={isRefreshing}
              className="px-2 py-1 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-all cursor-pointer"
              title="Manual Refresh Count Players"
            >
              <RefreshCw className={`w-3 h-3 ${isRefreshing ? "animate-spin" : ""}`} />
              <span>Refresh Counts</span>
            </button>
          )}
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-2xl lg:text-3xl font-black text-white font-mono tracking-tight">
            {tracked}
          </span>
          <span className="text-xs font-bold text-amber-400">
            🔥 {trendingCount} Viral
          </span>
        </div>
        <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1">
          <span>Rolimons Realtime Telemetry</span>
          {manualRefreshCount > 0 && (
            <span className="text-cyan-400 font-semibold text-[10px] bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20">
              {manualRefreshCount} Refreshes
            </span>
          )}
        </div>
      </div>

      {/* Network Health & Telemetry Pulse */}
      <div className="relative overflow-hidden bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-lg hover:border-indigo-500/40 transition-all group">
        <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-500/10 rounded-full blur-2xl group-hover:bg-indigo-500/20 transition-all pointer-events-none" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold text-slate-400">Telemetry Status</span>
          <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-400 border border-indigo-500/20">
            <Zap className="w-4 h-4" />
          </div>
        </div>
        <div className="flex items-baseline gap-2">
          <span className="text-xl font-black text-white font-mono tracking-tight">
            10s Live Sync
          </span>
          <span className="text-[10px] font-bold text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded border border-indigo-500/20">
            Active
          </span>
        </div>
        <p className="text-[11px] text-slate-500 mt-1">Real-time Roblox server stream active</p>
      </div>
    </div>
  );
};
