import React from "react";
import {
  X,
  Users,
  ThumbsUp,
  Globe2,
  Copy,
  Check,
  Play,
  Sparkles,
  Bookmark,
  Calendar,
  Layers,
  Activity,
  Flame,
  Radio
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { RobloxGame } from "../types";

interface GameDetailModalProps {
  game: RobloxGame | null;
  onClose: () => void;
  isWatchlisted: boolean;
  onToggleWatchlist: (game: RobloxGame) => void;
}

export const GameDetailModal: React.FC<GameDetailModalProps> = ({
  game,
  onClose,
  isWatchlisted,
  onToggleWatchlist,
}) => {
  const [copied, setCopied] = React.useState(false);

  if (!game) return null;

  // Format sparkline data for Recharts area graph
  const chartData = game.sparkline.map((val, idx) => {
    const hour = (idx * 2) % 24;
    const timeLabel = `${hour.toString().padStart(2, "0")}:00`;
    return {
      time: timeLabel,
      players: val,
    };
  });

  const handleCopyPlaceId = () => {
    navigator.clipboard.writeText(game.placeId);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const displayImage = (game.iconUrl || game.bannerUrl || "").replace(/\/150\/150\//g, "/512/512/");

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-md flex items-center justify-center p-4 sm:p-6 animate-in fade-in duration-200">
      <div className="relative w-full max-w-4xl bg-slate-900 border border-slate-800 rounded-3xl overflow-hidden shadow-2xl text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Banner Header */}
        <div className="relative h-48 sm:h-60 overflow-hidden bg-slate-950 shrink-0">
          <img
            src={displayImage}
            alt={game.name}
            referrerPolicy="no-referrer"
            onError={(e) => {
              (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=600&auto=format&fit=crop&q=80";
            }}
            className="w-full h-full object-cover opacity-80"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-slate-900 via-slate-900/50 to-transparent" />

          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 text-slate-300 hover:text-white bg-slate-950/80 hover:bg-slate-800 border border-slate-800 rounded-2xl transition-all cursor-pointer z-10"
          >
            <X className="w-5 h-5" />
          </button>

          {/* Title and Badges */}
          <div className="absolute bottom-4 left-4 right-4 flex flex-col sm:flex-row sm:items-end justify-between gap-3">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="px-2.5 py-0.5 text-xs font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 rounded-lg">
                  {game.category}
                </span>
                {game.isTrending && (
                  <span className="px-2.5 py-0.5 text-xs font-black bg-amber-500 text-slate-950 rounded-lg flex items-center gap-1">
                    <Flame className="w-3.5 h-3.5" /> Viral Trending
                  </span>
                )}
              </div>
              <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">{game.name}</h2>
              <p className="text-xs text-slate-300">
                Created by <strong className="text-cyan-400">{game.creator}</strong> • Released {game.releaseYear}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => onToggleWatchlist(game)}
                className={`px-3 py-2 rounded-xl text-xs font-bold border transition-all flex items-center gap-1.5 cursor-pointer ${
                  isWatchlisted
                    ? "bg-amber-500 text-slate-950 border-amber-400"
                    : "bg-slate-900/90 text-slate-200 hover:text-amber-400 border-slate-800"
                }`}
              >
                <Bookmark className="w-4 h-4 fill-current" />
                <span>{isWatchlisted ? "Watchlisted" : "Watchlist"}</span>
              </button>

              <a
                href={`https://www.roblox.com/games/${game.placeId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="px-4 py-2 bg-gradient-to-r from-emerald-500 to-cyan-500 text-slate-950 font-black text-xs rounded-xl shadow-lg shadow-emerald-500/20 hover:scale-105 transition-all flex items-center gap-1.5 cursor-pointer"
              >
                <Play className="w-4 h-4 fill-current" />
                <span>Play on Roblox</span>
              </a>
            </div>
          </div>
        </div>

        {/* Modal Scrollable Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 custom-scrollbar">
          
          {/* Key Metrics Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" /> Live Concurrent
              </span>
              <span className="text-xl font-black text-white font-mono">{game.activePlayers.toLocaleString()}</span>
            </div>

            <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
                <Activity className="w-3.5 h-3.5 text-cyan-400" /> 24h Peak
              </span>
              <span className="text-xl font-black text-cyan-300 font-mono">{game.peak24h.toLocaleString()}</span>
            </div>

            <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
                <ThumbsUp className="w-3.5 h-3.5 text-emerald-400" /> Upvote %
              </span>
              <span className="text-xl font-black text-emerald-400 font-mono">{game.upvotePercentage}%</span>
            </div>

            <div className="bg-slate-950/80 p-3.5 rounded-2xl border border-slate-800">
              <span className="text-[11px] text-slate-400 flex items-center gap-1 mb-1">
                <Layers className="w-3.5 h-3.5 text-amber-400" /> Total Visits
              </span>
              <span className="text-xl font-black text-amber-300 font-mono">{game.visits}</span>
            </div>
          </div>

          {/* 24-Hour Player Trend Area Chart */}
          <div className="bg-slate-950/80 p-4 rounded-2xl border border-slate-800">
            <div className="flex items-center justify-between mb-3">
              <h4 className="text-sm font-extrabold text-white flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400" />
                24-Hour Player Pulse History
              </h4>
              <span className="text-xs text-slate-400 font-mono">Real-time sync</span>
            </div>

            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData}>
                  <defs>
                    <linearGradient id="playerPulseGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.6} />
                      <stop offset="95%" stopColor="#06b6d4" stopOpacity={0.0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                  <XAxis dataKey="time" stroke="#64748b" fontSize={11} />
                  <YAxis
                    stroke="#64748b"
                    fontSize={11}
                    tickFormatter={(v) => (v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v)}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#090d16",
                      borderColor: "#334155",
                      borderRadius: "12px",
                      color: "#fff",
                    }}
                    formatter={(val: any) => [Number(val).toLocaleString(), "Players"]}
                  />
                  <Area
                    type="monotone"
                    dataKey="players"
                    stroke="#06b6d4"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#playerPulseGrad)"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Description & Tags */}
          <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2">Overview</h4>
            <p className="text-xs text-slate-200 leading-relaxed mb-3">{game.description}</p>

            <div className="flex flex-wrap gap-1.5">
              {game.tags.map((tag) => (
                <span
                  key={tag}
                  className="px-2.5 py-1 text-[11px] font-semibold bg-slate-900 text-slate-300 border border-slate-800 rounded-lg"
                >
                  #{tag}
                </span>
              ))}
            </div>
          </div>

          {/* Server Regions & Patch Notes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Server Regions */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800">
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-3 flex items-center gap-1.5">
                <Globe2 className="w-4 h-4 text-emerald-400" /> Active Server Regions
              </h4>
              <div className="space-y-2">
                {game.serverRegions.map((sr) => (
                  <div
                    key={sr.region}
                    className="flex items-center justify-between p-2.5 bg-slate-900 rounded-xl border border-slate-800 text-xs"
                  >
                    <span className="font-semibold text-slate-200">{sr.region}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-slate-400 font-mono">{sr.activeServers} servers</span>
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-mono">
                        {sr.latencyMs}ms
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Patch Notes & Place ID */}
            <div className="bg-slate-950/60 p-4 rounded-2xl border border-slate-800 flex flex-col justify-between">
              <div>
                <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <Calendar className="w-4 h-4 text-amber-400" /> Latest Patch Update
                </h4>
                <p className="text-xs text-slate-300 bg-slate-900 p-3 rounded-xl border border-slate-800 leading-relaxed mb-4">
                  "{game.updateLog}"
                </p>
              </div>

              {/* Copy Place ID & Rolimons Record Box */}
              <div className="bg-slate-900 p-3 rounded-xl border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-slate-500 block">Roblox Place ID</span>
                    <span className="text-xs font-mono font-bold text-cyan-400">{game.placeId}</span>
                  </div>
                  <button
                    onClick={handleCopyPlaceId}
                    className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 rounded-lg border border-slate-700 transition-all flex items-center gap-1 cursor-pointer"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? "Copied" : "Copy ID"}</span>
                  </button>
                </div>

                <a
                  href={`https://www.rolimons.com/game/${game.placeId}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-2 bg-indigo-950/80 hover:bg-indigo-900 text-indigo-300 font-bold text-xs rounded-lg border border-indigo-800/60 transition-all flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Globe2 className="w-3.5 h-3.5 text-indigo-400" />
                  <span>View Verified Place on Rolimons</span>
                </a>
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
};
