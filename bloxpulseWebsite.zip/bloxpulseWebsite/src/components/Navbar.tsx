import React from "react";
import { Menu, Activity, Search, RefreshCw, Bookmark, PlusCircle, Sparkles } from "lucide-react";

interface NavbarProps {
  onToggleDrawer: () => void;
  searchQuery: string;
  onSearchChange: (q: string) => void;
  totalActivePlayers: number;
  watchlistCount: number;
  onOpenWatchlist: () => void;
  onOpenAddGame: () => void;
  autoRefresh: boolean;
  onToggleAutoRefresh: () => void;
  isRefreshing: boolean;
  onManualRefresh: () => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  onToggleDrawer,
  searchQuery,
  onSearchChange,
  totalActivePlayers,
  watchlistCount,
  onOpenWatchlist,
  onOpenAddGame,
  autoRefresh,
  onToggleAutoRefresh,
  isRefreshing,
  onManualRefresh,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/90 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3 transition-all">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-4">
        {/* Left Section: Hamburger & Brand */}
        <div className="flex items-center gap-3">
          <button
            id="hamburger-menu-btn"
            onClick={onToggleDrawer}
            className="p-2.5 text-slate-300 hover:text-white bg-slate-900/80 hover:bg-slate-800 border border-slate-800 hover:border-cyan-500/50 rounded-xl transition-all cursor-pointer flex items-center justify-center focus:outline-none focus:ring-2 focus:ring-cyan-500/40"
            title="Toggle Hamburger Navigation Menu"
            aria-label="Open Navigation Drawer"
          >
            <Menu className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2.5 select-none">
            <div className="relative flex items-center justify-center w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 via-emerald-500 to-indigo-600 p-[1px] shadow-lg shadow-cyan-500/20">
              <div className="w-full h-full bg-slate-950 rounded-[11px] flex items-center justify-center">
                <Activity className="w-5 h-5 text-cyan-400 animate-pulse" />
              </div>
              <span className="absolute -top-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xl font-black tracking-tight text-white font-sans">
                  BLOX<span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400">PULSE</span>
                </span>
                <a
                  href="https://www.rolimons.com/games"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 text-[10px] font-bold bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 rounded-full uppercase tracking-wider transition-all"
                  title="Game telemetry referenced from Rolimons & Roblox API"
                >
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-400" />
                  Rolimons Verified
                </a>
              </div>
              <p className="text-[11px] text-slate-400 hidden md:block">Real-Time Roblox Map Telemetry • Referenced from Rolimons</p>
            </div>
          </div>
        </div>

        {/* Middle Section: Live Search */}
        <div className="flex-1 max-w-md hidden md:block">
          <div className="relative">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
            <input
              type="text"
              id="navbar-search-input"
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              placeholder="Search map name, creator, tag (e.g. Blox Fruits, FPS, Anime)..."
              className="w-full bg-slate-900/90 text-slate-100 text-sm pl-10 pr-4 py-2 rounded-xl border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/50 outline-none transition-all placeholder:text-slate-500"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Right Section: Tickers, Refresh, Watchlist & Add Game */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* Active Players Ticker Badge */}
          <div className="hidden lg:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs">
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
            </span>
            <span className="text-slate-400">Playing Now:</span>
            <span className="font-bold text-white font-mono">{totalActivePlayers.toLocaleString()}</span>
          </div>

          {/* Auto Sync Toggle & Manual Refresh Count */}
          <div className="flex items-center bg-slate-900/90 border border-slate-800 rounded-xl p-1 gap-1">
            <button
              id="manual-refresh-players-btn"
              onClick={onManualRefresh}
              disabled={isRefreshing}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
                isRefreshing
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                  : "bg-slate-800/80 hover:bg-slate-800 text-slate-200 hover:text-cyan-400 border border-slate-700/60"
              }`}
              title="Click to manually refresh active player counts right now"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? "animate-spin text-cyan-400" : "text-cyan-400"}`} />
              <span className="hidden sm:inline">{isRefreshing ? "Syncing..." : "Refresh Counts"}</span>
            </button>

            <button
              id="auto-sync-toggle-btn"
              onClick={onToggleAutoRefresh}
              className={`px-2 py-1.5 text-[11px] font-semibold rounded-lg transition-all cursor-pointer ${
                autoRefresh
                  ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                  : "text-slate-400 hover:text-slate-200"
              }`}
              title="Toggle automatic 10-second live player count updates"
            >
              {autoRefresh ? "10s Sync ON" : "10s Sync OFF"}
            </button>
          </div>

          {/* Watchlist Button */}
          <button
            id="watchlist-toggle-btn"
            onClick={onOpenWatchlist}
            className="relative p-2 text-slate-300 hover:text-amber-400 bg-slate-900/80 hover:bg-slate-800 border border-slate-800 rounded-xl transition-all cursor-pointer flex items-center justify-center"
            title="View Watchlist / Bookmarked Games"
          >
            <Bookmark className="w-4 h-4" />
            {watchlistCount > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-amber-500 text-slate-950 font-black text-[10px] w-4 h-4 rounded-full flex items-center justify-center border border-slate-950">
                {watchlistCount}
              </span>
            )}
          </button>

          {/* Add Custom Game Button */}
          <button
            id="add-custom-game-btn"
            onClick={onOpenAddGame}
            className="px-3 py-2 bg-gradient-to-r from-cyan-500 to-emerald-500 hover:from-cyan-400 hover:to-emerald-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg shadow-cyan-500/20 transition-all flex items-center gap-1.5 cursor-pointer"
          >
            <PlusCircle className="w-4 h-4" />
            <span className="hidden sm:inline">Track Place ID</span>
          </button>
        </div>
      </div>

      {/* Mobile Search Bar Row */}
      <div className="mt-2.5 md:hidden">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            placeholder="Search Roblox maps..."
            className="w-full bg-slate-900 text-slate-100 text-xs pl-9 pr-4 py-2 rounded-xl border border-slate-800 focus:border-cyan-500 outline-none"
          />
        </div>
      </div>
    </header>
  );
};
