import React from "react";
import { Activity, ShieldCheck, Globe, TrendingUp, Zap, Radio, Layers } from "lucide-react";
import { RobloxGame, PulseStats } from "../types";

interface NetworkAnalyticsViewProps {
  games: RobloxGame[];
  stats: PulseStats | null;
  onSelectGame: (game: RobloxGame) => void;
}

export const NetworkAnalyticsView: React.FC<NetworkAnalyticsViewProps> = ({
  games,
  stats,
  onSelectGame,
}) => {
  // Compute Category Share
  const categoryTotals: Record<string, number> = {};
  games.forEach((g) => {
    categoryTotals[g.category] = (categoryTotals[g.category] || 0) + g.activePlayers;
  });

  const totalPlayers = games.reduce((sum, g) => sum + g.activePlayers, 0) || 1;

  const categoryShare = Object.entries(categoryTotals).map(([cat, count]) => ({
    category: cat,
    players: count,
    percentage: ((count / totalPlayers) * 100).toFixed(1),
  })).sort((a, b) => b.players - a.players);

  // Top 5 Growth Games
  const topGrowth = [...games].sort((a, b) => b.growth24h - a.growth24h).slice(0, 5);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Network Overview Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-slate-900 via-slate-900 to-indigo-950/80 border border-slate-800 rounded-3xl p-6 shadow-2xl">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-2">
              <span className="px-2.5 py-0.5 text-xs font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-full flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" /> Live Telemetry
              </span>
              <span className="text-xs text-slate-400 font-mono">Last Pulse: {new Date().toLocaleTimeString()}</span>
            </div>
            <h2 className="text-2xl font-black text-white tracking-tight">Global Roblox Network Analytics</h2>
            <p className="text-xs text-slate-400 max-w-xl mt-1">
              Real-time monitoring of concurrent Roblox player volume, genre market share, region latency ping, and viral growth velocity.
            </p>
          </div>

          <div className="flex items-center gap-3 bg-slate-950/80 p-3 rounded-2xl border border-slate-800 shrink-0">
            <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl border border-cyan-500/20">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[10px] text-slate-500 block uppercase font-bold">Server Ping Health</span>
              <span className="text-sm font-black text-emerald-400 font-mono">99.98% Operational</span>
            </div>
          </div>
        </div>
      </div>

      {/* Grid: Category Market Share & Top Growth */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* Category Player Volume Market Share */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Layers className="w-4 h-4 text-cyan-400" />
              Category Player Share Distribution
            </h3>
            <span className="text-xs font-mono text-slate-400">{games.length} Categories</span>
          </div>

          <div className="space-y-3">
            {categoryShare.map((cs) => (
              <div key={cs.category} className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-bold text-slate-200">{cs.category}</span>
                  <span className="font-mono text-slate-400">
                    <strong className="text-cyan-300 font-bold">{cs.players.toLocaleString()}</strong> ({cs.percentage}%)
                  </span>
                </div>
                <div className="w-full h-2.5 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                  <div
                    className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 rounded-full transition-all duration-500"
                    style={{ width: `${cs.percentage}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Fastest 24h Growth Experiences */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-extrabold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-amber-400" />
              Top 24h Player Surge Leaderboard
            </h3>
            <span className="text-xs font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/20">
              Velocity
            </span>
          </div>

          <div className="space-y-2.5">
            {topGrowth.map((g, rank) => (
              <div
                key={g.id}
                onClick={() => onSelectGame(g)}
                className="flex items-center justify-between p-3 bg-slate-950/80 hover:bg-slate-950 rounded-2xl border border-slate-800 hover:border-cyan-500/40 transition-all cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <span className="w-6 h-6 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 font-mono text-xs font-bold flex items-center justify-center group-hover:text-cyan-400">
                    #{rank + 1}
                  </span>
                  <div>
                    <h4 className="text-xs font-bold text-white group-hover:text-cyan-400 transition-colors">
                      {g.name}
                    </h4>
                    <span className="text-[11px] text-slate-400">{g.category}</span>
                  </div>
                </div>

                <div className="text-right">
                  <span className="text-xs font-black text-emerald-400 font-mono flex items-center gap-0.5 justify-end">
                    <TrendingUp className="w-3 h-3" /> +{g.growth24h}%
                  </span>
                  <span className="text-[10px] text-slate-500 font-mono">
                    {g.activePlayers.toLocaleString()} playing
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

      </div>

      {/* Global Server Region Node Telemetry */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl">
        <h3 className="text-sm font-extrabold text-white mb-3 flex items-center gap-2">
          <Globe className="w-4 h-4 text-emerald-400" />
          Global Server Infrastructure Nodes
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-semibold block">US East (N. Virginia)</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-sm font-bold text-white font-mono">18ms Ping</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">Optimal</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-semibold block">US West (Oregon)</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-sm font-bold text-white font-mono">32ms Ping</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">Optimal</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-semibold block">EU Central (Frankfurt)</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-sm font-bold text-white font-mono">74ms Ping</span>
              <span className="text-[10px] text-emerald-400 font-bold bg-emerald-500/10 px-1.5 py-0.5 rounded">Good</span>
            </div>
          </div>

          <div className="bg-slate-950 p-3.5 rounded-2xl border border-slate-800">
            <span className="text-[10px] text-slate-500 font-semibold block">Asia East (Tokyo)</span>
            <div className="flex items-baseline justify-between mt-1">
              <span className="text-sm font-bold text-white font-mono">98ms Ping</span>
              <span className="text-[10px] text-amber-400 font-bold bg-amber-500/10 px-1.5 py-0.5 rounded">Stable</span>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
};
