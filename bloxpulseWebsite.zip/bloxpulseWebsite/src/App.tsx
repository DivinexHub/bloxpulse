import React, { useState, useEffect, useCallback, useMemo } from "react";
import { Navbar } from "./components/Navbar";
import { HamburgerDrawer } from "./components/HamburgerDrawer";
import { PulseHeaderStats } from "./components/PulseHeaderStats";
import { CategoryTabs } from "./components/CategoryTabs";
import { GameCard } from "./components/GameCard";
import { GameDetailModal } from "./components/GameDetailModal";
import { AddGameModal } from "./components/AddGameModal";
import { NetworkAnalyticsView } from "./components/NetworkAnalyticsView";
import { RobloxGame, PulseStats } from "./types";
import { Bookmark, Activity, Search, RefreshCw, Flame, Grid, ChevronDown } from "lucide-react";

export default function App() {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [games, setGames] = useState<RobloxGame[]>([]);
  const [pulseStats, setPulseStats] = useState<PulseStats | null>(null);
  
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [searchQuery, setSearchQuery] = useState<string>("");
  const [sortBy, setSortBy] = useState<string>("playing");
  
  const [activeView, setActiveView] = useState<"all" | "watchlist" | "analytics">("all");
  const [visibleCount, setVisibleCount] = useState<number>(24);
  
  // Local storage persisted watchlist
  const [watchlist, setWatchlist] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem("bloxpulse_watchlist");
      return saved ? JSON.parse(saved) : ["blox-fruits", "rivals"];
    } catch {
      return ["blox-fruits", "rivals"];
    }
  });

  const [selectedGameForModal, setSelectedGameForModal] = useState<RobloxGame | null>(null);
  const [addGameOpen, setAddGameOpen] = useState(false);
  
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [loadingInitial, setLoadingInitial] = useState(true);
  const [manualRefreshCount, setManualRefreshCount] = useState(0);
  const [lastUpdatedTime, setLastUpdatedTime] = useState<string | null>(null);

  // Reset pagination when filter changes
  useEffect(() => {
    setVisibleCount(24);
  }, [selectedCategory, searchQuery, sortBy, activeView]);

  // Sync watchlist to localStorage
  useEffect(() => {
    try {
      localStorage.setItem("bloxpulse_watchlist", JSON.stringify(watchlist));
    } catch (e) {
      console.error(e);
    }
  }, [watchlist]);

  // Fetch Games & Pulse Stats from Backend API
  const fetchData = useCallback(async (isManual = false) => {
    setIsRefreshing(true);
    if (isManual) {
      setManualRefreshCount((prev) => prev + 1);
    }
    try {
      const params = new URLSearchParams();
      if (selectedCategory && selectedCategory !== "All") {
        params.append("category", selectedCategory);
      }
      if (searchQuery) {
        params.append("search", searchQuery);
      }
      if (sortBy) {
        params.append("sortBy", sortBy);
      }
      if (isManual) {
        params.append("forceSync", "true");
      }
      params.append("_t", Date.now().toString());

      const statsParams = new URLSearchParams();
      if (isManual) {
        statsParams.append("forceSync", "true");
      }
      statsParams.append("_t", Date.now().toString());

      const [gamesRes, statsRes] = await Promise.all([
        fetch(`/api/games?${params.toString()}`),
        fetch(`/api/pulse-stats?${statsParams.toString()}`),
      ]);

      if (gamesRes.ok) {
        const gamesData = await gamesRes.json();
        setGames(gamesData);
      }

      if (statsRes.ok) {
        const statsData = await statsRes.json();
        setPulseStats(statsData);
      }
      
      const now = new Date();
      setLastUpdatedTime(now.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }));
    } catch (err) {
      console.error("Error fetching live Roblox pulse data:", err);
    } finally {
      setIsRefreshing(false);
      setLoadingInitial(false);
    }
  }, [selectedCategory, searchQuery, sortBy]);

  // Initial Load & Query Watcher
  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Auto Sync Pulse Heartbeat Timer (Every 10 Seconds)
  useEffect(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      fetchData();
    }, 10000);
    return () => clearInterval(interval);
  }, [autoRefresh, fetchData]);

  // Toggle Watchlist Handler
  const handleToggleWatchlist = (game: RobloxGame) => {
    setWatchlist((prev) => {
      if (prev.includes(game.id)) {
        return prev.filter((id) => id !== game.id);
      } else {
        return [...prev, game.id];
      }
    });
  };

  // Filter & sort games with high performance memoization
  const displayedGames = useMemo(() => {
    return games.filter((g) => {
      if (activeView === "watchlist") {
        return watchlist.includes(g.id);
      }
      return true;
    });
  }, [games, activeView, watchlist]);

  const paginatedGames = useMemo(() => {
    return displayedGames.slice(0, visibleCount);
  }, [displayedGames, visibleCount]);

  const trendingCount = useMemo(() => games.filter((g) => g.isTrending).length, [games]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans antialiased selection:bg-cyan-500 selection:text-slate-950">
      
      {/* Top Navbar Header */}
      <Navbar
        onToggleDrawer={() => setDrawerOpen(true)}
        searchQuery={searchQuery}
        onSearchChange={(q) => setSearchQuery(q)}
        totalActivePlayers={pulseStats?.totalActivePlayers || 0}
        watchlistCount={watchlist.length}
        onOpenWatchlist={() => setActiveView("watchlist")}
        onOpenAddGame={() => setAddGameOpen(true)}
        autoRefresh={autoRefresh}
        onToggleAutoRefresh={() => setAutoRefresh((prev) => !prev)}
        isRefreshing={isRefreshing}
        onManualRefresh={() => fetchData(true)}
      />

      {/* Hamburger Sliding Drawer */}
      <HamburgerDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        activeCategory={selectedCategory}
        onSelectCategory={(cat) => setSelectedCategory(cat)}
        activeView={activeView}
        onChangeView={(view) => setActiveView(view)}
        onOpenAddGame={() => setAddGameOpen(true)}
        watchlistCount={watchlist.length}
        totalTrackedGames={games.length}
      />

      {/* Main Content View Container */}
      <main className="max-w-7xl mx-auto px-4 lg:px-8 py-6">
        
        {/* Metric Banner Stats Bar */}
        <PulseHeaderStats
          stats={pulseStats}
          trendingCount={trendingCount}
          isRefreshing={isRefreshing}
          onManualRefresh={() => fetchData(true)}
          manualRefreshCount={manualRefreshCount}
          lastUpdatedTime={lastUpdatedTime}
        />

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2 mb-6 border-b border-slate-800/80 pb-3 overflow-x-auto custom-scrollbar">
          <button
            onClick={() => setActiveView("all")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
              activeView === "all"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Grid className="w-4 h-4" />
            <span>Map Directory ({games.length})</span>
          </button>

          <button
            onClick={() => setActiveView("watchlist")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
              activeView === "watchlist"
                ? "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Bookmark className="w-4 h-4 text-amber-400 fill-current" />
            <span>Watchlist ({watchlist.length})</span>
          </button>

          <button
            onClick={() => setActiveView("analytics")}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-2 cursor-pointer shrink-0 ${
              activeView === "analytics"
                ? "bg-indigo-500/20 text-indigo-300 border border-indigo-500/30"
                : "text-slate-400 hover:text-white hover:bg-slate-900"
            }`}
          >
            <Activity className="w-4 h-4 text-indigo-400" />
            <span>Telemetry & Health</span>
          </button>
        </div>

        {/* View Content Logic */}
        {activeView === "analytics" ? (
          <NetworkAnalyticsView
            games={games}
            stats={pulseStats}
            onSelectGame={(g) => setSelectedGameForModal(g)}
          />
        ) : (
          <>
            {/* Category Filter Pills & Sort Options */}
            {activeView === "all" && (
              <CategoryTabs
                selectedCategory={selectedCategory}
                onSelectCategory={(cat) => setSelectedCategory(cat)}
                sortBy={sortBy}
                onSortChange={(sort) => setSortBy(sort)}
                gameCount={displayedGames.length}
              />
            )}

            {/* Watchlist View Header Notice */}
            {activeView === "watchlist" && (
              <div className="mb-6 p-4 bg-amber-950/20 border border-amber-800/40 rounded-2xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <Bookmark className="w-5 h-5 text-amber-400 fill-current" />
                  <div>
                    <h3 className="text-sm font-extrabold text-amber-200">Bookmarked Experiences</h3>
                    <p className="text-xs text-slate-400">Monitoring real-time player counts for your selected Roblox maps.</p>
                  </div>
                </div>
                {displayedGames.length === 0 && (
                  <button
                    onClick={() => setActiveView("all")}
                    className="px-3 py-1.5 bg-amber-500 text-slate-950 font-bold text-xs rounded-xl"
                  >
                    Browse Directory
                  </button>
                )}
              </div>
            )}

            {/* Loading Grid Skeleton */}
            {loadingInitial ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                  <div
                    key={n}
                    className="h-80 bg-slate-900/60 border border-slate-800 rounded-2xl animate-pulse"
                  />
                ))}
              </div>
            ) : displayedGames.length === 0 ? (
              /* Empty State */
              <div className="py-16 text-center bg-slate-900/40 border border-slate-800 rounded-3xl p-8 max-w-lg mx-auto">
                <Search className="w-10 h-10 text-slate-600 mx-auto mb-3" />
                <h3 className="text-base font-extrabold text-white mb-1">No Roblox maps found</h3>
                <p className="text-xs text-slate-400 mb-4">
                  {searchQuery
                    ? `No experiences matching "${searchQuery}". Try a different keyword or clear filters.`
                    : activeView === "watchlist"
                    ? "Your watchlist is currently empty. Star maps in the directory to track them here!"
                    : "No maps found for this category."}
                </p>
                <button
                  onClick={() => {
                    setSearchQuery("");
                    setSelectedCategory("All");
                    setActiveView("all");
                  }}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700"
                >
                  Reset All Filters
                </button>
              </div>
            ) : (
              /* Optimized Roblox Experiences Grid */
              <div className="space-y-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
                  {paginatedGames.map((game) => (
                    <GameCard
                      key={game.id}
                      game={game}
                      onSelectGame={(g) => setSelectedGameForModal(g)}
                      isWatchlisted={watchlist.includes(game.id)}
                      onToggleWatchlist={handleToggleWatchlist}
                    />
                  ))}
                </div>

                {/* Load More Pagination Bar */}
                {displayedGames.length > visibleCount && (
                  <div className="flex flex-col items-center justify-center pt-6 pb-2 border-t border-slate-800/60 gap-3">
                    <p className="text-xs text-slate-400 font-medium">
                      Showing <strong className="text-cyan-400 font-mono">{paginatedGames.length}</strong> of <strong className="text-white font-mono">{displayedGames.length}</strong> live Roblox experiences
                    </p>
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setVisibleCount((prev) => prev + 24)}
                        className="px-5 py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs rounded-xl border border-slate-700 transition-all flex items-center gap-2 shadow-lg cursor-pointer"
                      >
                        <ChevronDown className="w-4 h-4 text-cyan-400" />
                        <span>Load More Experiences (+24)</span>
                      </button>
                      <button
                        onClick={() => setVisibleCount(displayedGames.length)}
                        className="px-4 py-2.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 font-bold text-xs rounded-xl border border-cyan-500/30 transition-all cursor-pointer"
                      >
                        Show All ({displayedGames.length})
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}

      </main>

      {/* Modals */}
      <GameDetailModal
        game={selectedGameForModal}
        onClose={() => setSelectedGameForModal(null)}
        isWatchlisted={selectedGameForModal ? watchlist.includes(selectedGameForModal.id) : false}
        onToggleWatchlist={handleToggleWatchlist}
      />

      <AddGameModal
        isOpen={addGameOpen}
        onClose={() => setAddGameOpen(false)}
        onGameAdded={fetchData}
      />

      {/* Footer */}
      <footer className="mt-16 border-t border-slate-800/80 bg-slate-950 py-8 px-4 text-center text-xs text-slate-500">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="font-extrabold text-slate-300">BLOX<span className="text-cyan-400">PULSE</span></span>
            <span>— Real-time Roblox Player Counts & Map Telemetry</span>
          </div>
          <p className="text-slate-500">
            Real-Time Telemetry & Live Player Analytics
          </p>
        </div>
      </footer>

    </div>
  );
}
