export interface ServerRegion {
  region: string;
  latencyMs: number;
  activeServers: number;
}

export interface RobloxGame {
  id: string;
  name: string;
  creator: string;
  category: string;
  activePlayers: number;
  peak24h: number;
  visits: string;
  upvotePercentage: number;
  iconUrl: string;
  bannerUrl: string;
  description: string;
  tags: string[];
  placeId: string;
  universeId?: string;
  releaseYear: number;
  serverRegions: ServerRegion[];
  updateLog: string;
  isTrending: boolean;
  growth24h: number;
  sparkline: number[];
  rolimonsUrl?: string;
  isRolimonsVerified?: boolean;
  lastSyncedAt?: string;
  reactions?: Record<string, number>;
  vibeRatings?: {
    grind: number; // 1-5
    afk: number; // 1-5
    p2w: number; // 1-5
    hype: number; // 1-5
    totalVotes: number;
  };
}

export interface PulseStats {
  totalActivePlayers: number;
  totalPeak24h: number;
  trackedGames: number;
  trendingCount: number;
  serverHealthStatus: string;
  lastPulseTimestamp: string;
}

export interface AIAnalysis {
  trendReason: string;
  metaSecrets: string[];
  serverAdvice: string;
  futureOutlook: string;
}

export interface CommunityData {
  reactions: Record<string, number>;
  vibeRatings: {
    grind: number;
    afk: number;
    p2w: number;
    hype: number;
    totalVotes: number;
  };
}

export interface GameCode {
  id: string;
  placeId: string;
  gameName: string;
  code: string;
  rewards: string;
  status: "Active" | "Expired" | "Newly Added";
  verifiedDate: string;
  upvotes: number;
  iconUrl?: string;
}

export interface UpdateEvent {
  id: string;
  placeId: string;
  gameName: string;
  title: string;
  patchVersion: string;
  releaseTimestamp: string; // ISO string or date
  description: string;
  hypeCount: number;
  majorFeatures: string[];
  iconUrl?: string;
}

export interface HistoricalTelemetryPoint {
  label: string;
  players: number;
  peak: number;
  activeServers: number;
}

export interface HistoricalTelemetry {
  period: "24h" | "7d" | "30d";
  points: HistoricalTelemetryPoint[];
  peakPeriod: number;
  averagePlayers: number;
  growthDelta: number;
  stabilityScore: string;
}

